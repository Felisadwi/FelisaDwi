<?php	
$server="localhost"; 
$nama_db="webdesa";
$user="root";
$pass="";

$koneksi=mysql_connect($server, $user, $pass);
mysql_select_db($nama_db, $koneksi);
?>