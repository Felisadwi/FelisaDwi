<?php
include 'db.php';
$username=$_POST['username'];
$password=$_POST['password'];

$query="SELECT * FROM user WHERE Nama = '$username' AND Password = '$password'";
$apa=$connect->query($query);



if ($apa->num_rows >0) {
  session_start();
  $_SESSION['username'] = $username;
  header("Location: index.php");
} else {
    echo "gagal login";
}
?>
