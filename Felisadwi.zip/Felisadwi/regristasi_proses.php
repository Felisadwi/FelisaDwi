<?php 

include 'konekksi.php';

$email=$_POST['email'];
$pass=$_POST['password'];
$nama=$_POST['nama'];


mysql_query("INSERT INTO `user`( `email`, `password`, `nama`) VALUES ('$email','$pass','$nama')");


echo "GUNAKKAN EMAIL DAN PASSWORD DIBAWAH INI UNTUK LOGIN";
echo "<br> ";echo "Email :  ";
echo $email;
echo "<br> ";
echo "Password :  ";
echo $pass;
echo "<br> ";
echo "<a href='halaman_login.php'> BERHASIL <a/>";
 ?>
