<?php
require 'proses_artikel.php';
$artikel = query("SELECT * FROM artikel ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Sinopsis Drakor</title>
</head>
<body>
<link rel="stylesheet" href="css/styletampilberita.css">
  <body>
    <div class="sidebar">
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="artikel_tambah.php">Tambah Berita</a></li>
        <li><a href="daftaruser.php">Daftar User</a></li>
        </ul>
    </div>
    <div class="bgjudul">
      <p class="merek">Sinopdrakor</p>
    </div>
    <div class="atas">
      <button class="tulisatas"><a href="logout.php" onclick="return confirm('Yakin Ingin Keluar ?');">Logout</a></button>

      <form action="" method="post">
  <input type="text" name="keyword" size="35" autofocus placeholder="Searching..." autocomplete="off">
  <button type="submit" name="cari">Search</button>
</form>

    </div>
    
    <div class="judullist">
    	<p><b>List Sinopsis Drakor</b></p>
    </div>
    <section id="bighit">
      <div class="bts">
        <article class="" id="main-col">
              <?php $i = 1; foreach ( $artikel as $row ) : ?>
                <?php if ($i == 1): ?>
                  <div class="box">
                    <div class="new">
                      <p class="judul"><?= $row["judul"]; ?></p>
                      <p>Oleh : <?= $row["penulis"];  ?></p><hr>
                      <p><?= substr($row["isi"],0, 40);  ?></p>
                      <a href="readmore.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Read-more</button></a>
                      <a href="ubah_artikel.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Edit</button></a>
                      <a href="hapus_berita.php?id=<?= $row["id"];?>" onclick="return confirm('Anda yakin akan menghapus data?')" style="text-decoration:none;"><button type="button" name="button" class="read">Hapus</button></a>
                    </div>
                  </div>
                  <?php $i++; else: ?>
                    <section id="boxes">
                        <div class="box">
                          <div class="last">
                            <h3><?= $row["judul"]; ?></h3>
                            <p>Di tulis oleh : <?= $row["penulis"];  ?></p><hr>
                            <p><?= substr($row["isi"],0, 40);  ?></p>
                            <a href="readmore.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Read-more</button></a>

                            <a href="ubah_artikel.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Edit</button></a>

                            <a href="hapus_berita.php?id=<?= $row["id"]; ?>" onclick="return confirm('Anda yakin akan menghapus data?')"><button type="button" name="button" class="read">Hapus</button></a>

                          </div>
                        </div>

                    </section>
                <?php endif; ?>

              <?php endforeach; ?>

          </article>

    </section>

  </body>
</html>