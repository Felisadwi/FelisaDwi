<?php
require 'proses_artikel.php';
$id = $_GET["id"];
if ( hapus($id) > 0) {
  echo "
  <script>
    alert('Data berhasil dihapus!!');
    document.location.replace('dashboard.php');
  </script>
  ";
}else {
  echo "
  <script>
    alert('Gagal Menghapus!');
  </script>
  ";
}

 ?>
