<!DOCTYPE html>
<html>
<head>
<title>Halaman Utama</title>
<style type="text/css">
body{
	font-family: arial;
	font-size: 14px;
}

#canvas{
	width: 960px;
	margin: 0 auto;
	border: 1px solid silver;
}
#header{
	font-size: 20px;
	padding: 20px;
}

#menu{
	background-color: #0066ff;
}
#menu ul{
	list-style: none;
	margin: 0;
	padding: 0;
}
#menu ul li{
	display: inline-table;	
}
#menu ul li:hover{
	background-color: #0033cc; 
}
#menu ul li a{
	display: block;
	text-decoration: none;
	line-height: 40px;
	padding: 0 10px;


}


#isi{
	min-height: 400px;
	padding: 20px;
	
}

#footer{
	text-align: center;
	padding : 20px;
	background-color: #ccc; 
	
}
</style>
</head>
<body>
<div id="canvas">	
	
	<div id="header">
		Selamat Datang Di Halaman Utama
	</div>

	<div id="menu">
		<ul>
			<li><a href="index.php">Beranda</a></li>
			<li><a href="biodata.php">Profil</a></li>
			<li><a href="Artikel.php">Artikel</a></li>
			<ul class="nav-navbar-nav-navbar-right">
				<li><a href="halaman_login.php">Log Out<span style="font-size: 16px;" class="pull-right hidden-xs showpacity glyphicon glyphicon-off"></span></a></li>

		</ul>
	</div>

	<div id="isi">
		<center><h2>Welcome!1!1</h2></center>
	</div>

	<div id="footer">
		Copyright 2018 Felisa Dwi Utami Putri
	</div>

</body>
</html>