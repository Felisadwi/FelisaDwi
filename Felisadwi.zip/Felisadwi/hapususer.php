<?php 
require 'proses_artikel.php';

$id=$_GET["id"];


if(hapususer($id) > 0 ) {
 	 echo "
		<script> 
		alert ('User Berhasil Dihapus');
		document.location.href = 'daftaruser.php'; 
		</script> 
		";
	} else {
		echo "		
		<script> 
		alert ('User Gagal Dihapus');
		document.location.href = 'daftaruser.php'; 
		</script>
		";
 }
 ?>
