<?php
$h='localhost';
$u ='root';
$p ='';
$db ='webku';
$connect = new mysqli($h, $u, $p, $db);
if ($connect->connect_error){
}
?>