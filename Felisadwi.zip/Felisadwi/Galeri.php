<html>
<head>
<title>Kebutuh Duwur Village</title>
<style>
   body {
	background-color : black;
     width: 736px;
     margin: 10px auto;
     border: 2px solid black;
   }
   img {
     border: 4px solid violet;
     margin: 20px;
     padding: 10px;
     width: 300px;
     height: 300px;
   }

</style>
<title>Galeri</title>
<link rel="stylesheet" href="style.css"/>
</head>
<body>
<center><h2>Galeri Desa</h2></center>
<img class="gambar1" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_072931.jpg"><img class="gambar2" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_072949.jpg">
<img class="gambar3" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_073047.jpg"><img class="gambar4" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_073458.jpg">
<img class="gambar5" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_073604.jpg"><img class="gambar6" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_073947.jpg">
<img class="gambar7" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_074136.jpg"><img class="gambar8" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_074828.jpg">
<img class="gambar9" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_074838.jpg"><img class="gambar10" src="file:///C:/Users/ACER/Documents/14872/14872/20171118_080811.jpg">
</body>
</html>