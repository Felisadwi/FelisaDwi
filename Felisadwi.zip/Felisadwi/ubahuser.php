<?php 
require 'proses_artikel.php';

// ambil data di url 
$id = $_GET["id"];

// query data tamu 
$tm = query("SELECT * FROM user WHERE id = $id")[0];

// cek submit sdh ditekan 
if ( isset ($_POST["submit"]) ) {

	// cek keberhasilan pengubahan data
	if (ubahuser($_POST) > 0 ) {
		echo "
			<script> 
			alert('Data User Berhasil Diubah');
			document.location.href = 'daftaruser.php'; 
			  </script>
			";
	} else {
		echo "<script> 
				alert('Data User Berhasil Diubah');
				document.location.href = 'daftaruser.php'; 
			  </script>";
	}
}
 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data</title>
</head>
<body>
<h1>Ubah Data User</h1>
<form action="" method="post">
	<input type="hidden" name="id" value="<?= $tm["id"]; ?>">
	<ul>
		<li>
			<label for="nama">Nama : </label>
			<input type="text" name="nama" id="nama" required value="<?= $tm["nama"]; ?>">
		</li>
		<li>
			<label for="password">Password : </label>
			<input type="password" name="password" id="password" value="<?= $tm["password"]; ?>">
		</li>
		<li>
			<button type="submit" name="submit">Ubah data</button>
		</li>
	</ul>
	

</form>

</body>
</html>