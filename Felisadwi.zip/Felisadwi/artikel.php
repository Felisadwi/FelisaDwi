<?php
require 'proses_artikel.php';
$artikel = query("SELECT * FROM artikel ORDER BY id DESC");
?>


<html>
    <head>
        <title>Halaman Beranda</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>
      <header>
        <ul>
          <a href="index.php"><li>Beranda</li></a>
          <a href="artikel.php"><li>Artikel</li></a>
          <a href="logout.php"><li>keluar</li></a>


        </ul>
      </header>

      <section>

        <center>
        <article class="" id="main-col">
              <?php $i = 1; foreach ( $artikel as $row ) : ?>
                <?php if ($i == 1): ?>
                  <div class="box">
                    <div class="new">
                      <p class="judul"><?= $row["judul"]; ?></p>
                      <p>Oleh : <?= $row["pengarang"];  ?></p><hr>
                      <p><?= substr($row["sinopsis"],0, 40);  ?></p>
                      <a href="readmore.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Read-more</button></a><br>
                      <a href="ubah_artikel.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Edit</button></a><br>
                      <a href="hapus_berita.php?id=<?= $row["id"];?>" onclick="return confirm('Anda yakin akan menghapus data?')" style="text-decoration:none;"><button type="button" name="button" class="read">Hapus</button></a>
                    </div>
                  </div>
                  <?php $i++; else: ?>
                    <section id="boxes">
                        <div class="box">
                          <div class="last">
                            <h3><?= $row["judul"]; ?></h3>
                            <p>Di tulis oleh : <?= $row["pengarang"];  ?></p><hr>
                            <p><?= substr($row["isi"],0, 40);  ?></p>
                            <a href="readmore.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Read-more</button></a>

                            <a href="ubah_artikel.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Edit</button></a>

                            <a href="hapus_berita.php?id=<?= $row["id"]; ?>" onclick="return confirm('Anda yakin akan menghapus data?')"><button type="button" name="button" class="read">Hapus</button></a>

                          </div>
                        </div>

                    </section>
                <?php endif; ?>

              <?php endforeach; ?>

          </article>

        </center>
      </section>

      <footer>
        Copyright &copy; Felisa dwi utami putri X RPL 1. All right reserved.
      </footer>

    </body>
</html>
