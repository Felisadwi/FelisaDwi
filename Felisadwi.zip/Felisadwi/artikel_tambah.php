<?php
require 'proses_artikel.php';
if (isset($_POST["submit"])) {
// cek data berhasil ditamabahkan atau tidak
if ( tambah($_POST) > 0) {
  echo "
  <script>
    alert('Berita Berhasil Ditambahkan');
    document.location.href= 'index.php';
  </script>
  ";
}else {
  echo "
  <script>
    alert('Berita Gagal Ditambahkan');
    document.location.href= 'artikel_tambah.php';
  </script>
  ";
  }
}
?> 

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Tulis Artikel</title>
  </head>
    <link rel="stylesheet" href="css/styleartikel_tambah.css">

  <body>
<div class="sidebar">
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="artikel_tambah.php">Tambah Berita</a></li>
        <li><a href="daftaruser.php">Daftar User</a></li>
        </ul>
    </div>
    <div class="bgjudul">
      <p class="merek">Sinopdrakor</p>
    </div>
    <div class="atas">
      <button class="tulisatas"><a href="logout.php" onclick="return confirm('Yakin Ingin Keluar ?');">Logout</a></button>
    </div>

      <h3>Tambah Berita</h3>
    <div class="loginbox">
    <form action="" method="post">
        <p>Judul</p>
        <input class="judul"  type="text" required name="judul" value="" autocomplete="off" placeholder="Judul Berita"><br><br>
        <p>Pengarang</p>
        <input class="penulis" type="text" required name="penulis" value="" autocomplete="off" placeholder="Penulis"><br>
        <p>sinopsis</p>
        <textarea class="isi" type="text" required name="isi" value="" autocomplete="off" placeholder="Isi" rows="9" cols="82" class="textarea"></textarea><br><br>
        <button type="submit" name="submit" class="submit">Simpan</button><br><br>
      </form> 
       </div>
  </body>
   </html>   