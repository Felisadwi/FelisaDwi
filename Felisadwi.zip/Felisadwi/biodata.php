<html>
<head>
<meta name="description" content="Biodata"/>
<meta name="Keywords" content="Biodata"/>
<meta name="authors" content="Felisa"/>
<meta charset="UTF-8"/>
<title>Biodata</title>
<link rel="stylesheet" href="styleku.css"/>
</head>
<body>
<form action="#" style="width: 1000px"class="posisi";>
<fieldset class="h"/>
<table style="width: 980px;">
<tr>
<td rowspan="15" width="250px">
<img src="felisadwi.jpg" width="250px" height="420px"/>
</td>
</tr>
<tr>
<td><b>Nama Lengkap</b></td>
<td>:</td>
<td>Felisa Dwi Utami Putri</td>
</tr>
<tr>
<td><b>Nama Panggilan</b></td>
<td>:</td>
<td>Felisa</td>
</tr>
<tr>
<td><b>Tempat, Tanggal Lahir</b></td>
<td>:</td>
<td>Banjarnegara, 5 Februari 2002</td>
</tr>
<tr>
<td><b>Umur</b></td>
<td>:</td>
<td>15 Tahun</td>
</tr>
<tr>
<td><b>Jenis Kelamin</b></td>
<td>:</td>
<td>Perempuan</td>
</tr>
<tr>
<td><b>Hobi</b></td>
<td>:</td>
<td>Nonton Anime</td>
</tr>

<tr>
<td><b>Gol. Darah</b></td>
<td>:</td>
<td>O</td>
</tr>
<tr>
<td><b>Agama</b></td>
<td>:</td>
<td>Islam</td>
</tr>
<tr>
<td><b>Alamat</b></td>
<td>:</td>
<td>Kebutuh Duwur, Pagedongan<br>Banjarnegara, Indonesia</td>
</tr>
<tr>
</tr>
<tr>
<td><b>Pekerjaan</b></td>
<td>:</td>
<td>Siswa</td>
</tr>
<tr>
<td><b>Kewarganegaraan</b></td>
<td>:</td>
<td>Indonesia</td>
</tr>

</td>

</table>
</fieldset>
</form>
</body>
</html>