<!DOCTYPE html>
<html>
  <head>
    <title>Halaman Login</title>
    <style type="text/css">
  body{
        font-family: arial;
        font-size: 14px;
        background-image: url(bgweb.jpg);
        background-size: cover;
  }
  #utama{
          width:400px;
          margin: 0 auto;
          margin-top: 12%;
  }
  .judul{
        padding: 15px;
        text-align: center;
        color: #fff;
        font-size: 20px;
        background-color: black;
        border-top-right-radius: 10px;
        border-bottom-left-radius: 10px;
        border-bottom: 3px solid brown;
  }
  .inputan{
            background-color:brown;
            padding: 20px;
            border-bottom-right-radius: 20px;
            border-bottom-left-radius: 10px;
  }
  input{
        padding:10px;
        border:0;
  }
  .lg{
      width: 240px;
  }
.btn{
    background-color: black;
    border-radius: 10px;
    color: #fff;
    width: 150px;
    height: 44px;
}
.btn:hover{
  background-color: brown;
  cursor: pointer;
}
.sign{
  background-color: black;
    border-radius: 10px;
    color: #fff;
    width: 150px;
    height: 45px;
}
.sign a{
  text-decoration: none;
  color: white;
}
.sign:hover{
  background-color: brown;
  cursor: pointer;
}
</style>
</head>
<body>
      <div id="utama">
        <h1 class="judul">Halaman Login</h1>
        <form class="inputan" action="index.php" method="post">
          <table>
              <tr>
                  <td><input type="text" name="username" value="" placeholder="username" class="lg"></td>
                </tr>
                <tr style="margin-top:10px">
                    <td><input type="password" name="password" value="" placeholder="pasword" class="lg"></td>
                  </tr>
                  <tr style="margin-top:10px; text-align:center;">
                      <td><input type="submit" name="submit" value="submit" class="btn">
                      <a href="registrasi.php">Sign up</td>

</tr>    
</table>
</form>
</div>
</body>
</html>