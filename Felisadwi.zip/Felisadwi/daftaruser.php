<?php 
require 'proses_artikel.php';
$user = query("SELECT * FROM user");
 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Daftar User</title>
</head>
<body>
<link rel="stylesheet" type="text/css" href="css/styledaftaruser.css">
  <body>
    <div class="sidebar">
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="artikel_tambah.php">Tambah Berita</a></li>
        <li><a href="daftaruser.php">Daftar User</a></li>
        </ul>
    </div>
    <div class="bgjudul">
      <p class="merek">Sinopdrakor</p>
    </div>
    <div class="atas">
      <button class="tulisatas"><a href="logout.php" onclick="return confirm('Yakin Ingin Keluar ?');">Logout</a></button>

  	<form action="" method="post">
  		<input type="text" name="keyword" size="35" autofocus placeholder="Searching..." autocomplete="off" class="keyword">
		<button type="submit" name="cari">Search</button>
	</form>
	
    </div>
    <div class="judullist">
    	<p><b>List Sinopsis Drakor</b></p>
    </div>
<h3>Daftar User</h3>
<table>

	<tr>
		<th>No.</th>
		<th>Aksi</th>
		<th>Nama</th>
		<th>Password</th>
	</tr>
<?php $i = 1; ?>
<?php foreach ( $user as $row ) : ?>
	
	<tr>
		<td><?= $i; ?></td>
		<td>
			<a href="ubahuser.php?id=<?= $row["id"]; ?>">Ubah</a> |
			<a href="hapususer.php?id=<?= $row["id"]; ?>" onclick="return confirm('Anda yakin akan menghapus data?')">Hapus</a>
		</td>
		<td><?= $row["nama"]; ?></td>
		<td><?= $row["password"]; ?></td>
	</tr>
	<?php $i++; ?>
<?php endforeach; ?>
</table>

</body>
</html>