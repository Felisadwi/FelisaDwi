<?php
require 'proses_berita.php';

// ambil dat di url--
$ID = $_GET["id"];
// query data mahasiswa berdasarka ID
$artikel =query("SELECT *FROM artikel WHERE id = $ID")[0];
if (isset($_POST["submit"])) {
// cek data berhasil ubah
if ( Edit($_POST) > 0) {

 echo "
 <script>
   alert('Artikel Berhasil Diubah!');
   document.location.href= 'dashboard.php';
 </script>
 ";
}else {
 echo "
 <script>
 alert('Artikel Gagal Diubah!');
 </script>
 ";
 }
}

?>

<!DOCTYPE html>
<html>
 <head>
   <meta charset="utf-8">
   <title>Dashboard | Edit User</title>
 </head>
 <link rel="stylesheet" href="css/styleArtikel.css">

 <body>
<body>
<link rel="stylesheet" href="css/styleubah_artikel.css">
    <body>
    <div class="sidebar">
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="artikel_tambah.php">Tambah Berita</a></li>
        <li><a href="daftaruser.php">Daftar User</a></li>
        </ul>
    </div>
    <div class="bgjudul">
      <p class="merek">Sinopdrakor</p>
    </div>
    <div class="atas">
      <button class="tulisatas"><a href="logout.php" onclick="return confirm('Yakin Ingin Keluar ?');">Logout</a></button>
    </div>
   <div class="loginbox">
    <h3>Edit pengguna</h3>

     <form class="" action="" method="post">
       <input type="hidden" name="id" value="<?= $artikel["id"]; ?>">
       <input  type="text"  name="judul" value="<?= $artikel["judul"]; ?>" autocomplete="off" placeholder="Judul" required><br><br>
       <input  type="text" required name="penulis" value="<?= $artikel["penulis"]; ?>" autocomplete="off" placeholder="penulis"><br>
       <textarea style="resize:none;" name="isi" rows="9" cols="82" value="" placeholder="Isi" class="textarea"><?= $artikel["isi"]; ?></textarea><br><br>
     <button type="submit" name="submit" class="submit">Kirim</button><br>
     </form>

   </div>

 </body>
</html>
