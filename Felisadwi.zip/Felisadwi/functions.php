<?php 
$conn = mysqli_connect("localhost","root","","siswa");


function query($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}


function tambah($data) {
	global $conn;
	$nama = htmlspecialchars($data["nama"]);
	$email = htmlspecialchars($data["email"]);
	$password = htmlspecialchars($data["password"]); 

	$query = "INSERT INTO daftar 
			VALUES
			('', '$nama','$email','$password')
			";
	mysqli_query($conn,$query);

	return mysqli_affected_rows($conn);
}


function hapus($id) {
	global $conn; 
	mysqli_query($conn,"DELETE FROM daftar WHERE id = $id"); 
	return mysqli_affected_rows($conn);
}

function ubah($data) { 
		global $conn;

		$id = $data["id"];
	$nama = htmlspecialchars($data["nama"]);
	$email = htmlspecialchars($data["email"]);
	$password = htmlspecialchars($data["password"]); 

	$query = "UPDATE daftar SET
			nama = '$nama',
			email = '$email',
			password = '$password'

			WHERE id = $id
			";
	mysqli_query($conn,$query);

	return mysqli_affected_rows($conn);

}



function cari($keyword) {
	$query = "SELECT * FROM daftar 
				WHERE 
				nama LIKE '%$keyword%' OR 
				email LIKE '%$keyword%' OR 
				password LIKE '%$keyword%' 
				";

	return query($query);
	
}


function tambahpengguna($post) {
	global $conn;

	$nama = htmlspecialchars($post["nama"]);
	$password = htmlspecialchars($post["password"]);

	// cek username sudah ada atau belum
	$result= mysqli_query($conn,"SELECT nama FROM user WHERE nama = '$nama' AND password = '$password'");
	if(mysqli_fetch_assoc($result) ){
		echo "<script>
				alert('Username sudah terdaftar!')
			</script>
		";
		return false;
	}

	
	// tambahkan userbaru ke database
	$query = "INSERT INTO user VALUES('', '$nama','$password')";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);
	}

 ?>